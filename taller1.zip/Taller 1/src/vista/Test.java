/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.util.ArrayList;

/**
 *
 * @author pmart
 */
public class Test {
        public static void main(String[] args) {
        //Crear mi objeto
        //Constructor vacio y utilizacion de metodos set
       estudiante estudiante = new estudiante();
       estudiante.setNombre("Javier");
       estudiante estudiante1 = new estudiante("Pablo", "12345678911", "ICII",
        "pablo.martinez@ufrontera.cl");
       estudiante estudiante2 = new estudiante();
       estudiante2.setNombre("Juan");
       estudiante estudiante3 = new estudiante();
       estudiante3.setNombre("Maria");
//        String nombre = "Pablo";
//        estudiante.setNombre(nombre);
//        estudiante.setMatricula("12345678911");
//        estudiante.setCarrera("ICII");
//        estudiante.setCorreo("pablo.martinez@ufrontera.cl");
//        System.out.println(estudiante.toString());

        ArrayList<estudiante> estudiantes = new ArrayList<>();
        estudiantes.add(estudiante1);
        estudiantes.add(estudiante);
        estudiantes.add(estudiante2);
        estudiantes.add(estudiante3);
        for (int i = 0; i < estudiantes.size(); i++) {
            System.out.println(estudiantes.get(i).toString());
            System.out.println("------------------------------");
        }
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getNombre().equalsIgnoreCase("Pablo")) {
                estudiantes.remove(i);
            }
        }
        System.out.println("DESPUES DE LA ELIMINACION");
        for (int i = 0; i < estudiantes.size(); i++) {
            System.out.println(estudiantes.get(i).toString());
            System.out.println("------------------------------");
        }
    }
}
    

