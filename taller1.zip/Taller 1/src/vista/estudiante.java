/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

/**
 *
 * @author pmart
 */
public class estudiante {
    
 //Nombre - Apellido - RUT - Matricula - Carrera - Edad - Correo
    //Variables
    //modificador de acceso: private - public - protected
    //tipo de dato: int - double - char - String - boolean - etc...
    //nombre variable: debe comenzar con una letra minuscula
    private String nombre;
    private String matricula;
    private String carrera;
    private String correo;
    
    //Crear el constructor de la clase
    //Clase sobrecargada: mas de un constructor
    public estudiante(){} //Constructor vacio
    
    public estudiante(String nombre,
            String matricula, String carrera,
            String correo){
        //this: hace referencia a las variables de la clase
        this.nombre = nombre;
        this.matricula = matricula;
        this.carrera = carrera;
        this.correo = correo;
    } //Constructor lleno
    
    //Metodos set y get
    //get: obtener los valores de mis variables
    //set: modificar los valores de mis variables
    //Metodos get
    public String getNombre(){return this.nombre;}    
    public String getMatricula(){return this.matricula;}
    public String getCarrera(){return this.carrera;}
    public String getCorreo(){return this.correo;}
    //Metodos set
     public void setNombre(String n){this.nombre = n;}
     public void setMatricula(String m){this.matricula = m;}
     public void setCarrera(String c){this.carrera = c;}
     public void setCorreo(String co){this.correo = co;}
     //toString: sirve para "mostrar" los valores de mi objeto
    @Override
    public String toString(){
        String cadena = "";
        cadena += "Nombre: " + this.nombre +
                "\nMatricula: " + this.matricula +
                "\nCarrera: " + this.carrera +
                "\nCorreo: " + this.correo;
        return cadena;
    } 
}